<?php
	// Silence is Golden by OCHOA