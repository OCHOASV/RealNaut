<?php
/*
	OCHOA Menu
*/

/* For PHP OCHOA_Menu */
require_once 'php_OCHOA_Menu.php';

/* For CSS OCHOA_Menu */
require_once 'css_OCHOA_Menu.php';

/* For JS OCHOA_Menu */
require_once 'js_OCHOA_Menu.php';